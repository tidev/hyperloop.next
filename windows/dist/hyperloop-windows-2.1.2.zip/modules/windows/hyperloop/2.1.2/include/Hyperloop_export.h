
#ifndef HYPERLOOP_EXPORT_H
#define HYPERLOOP_EXPORT_H

#ifdef HYPERLOOP_STATIC_DEFINE
#  define HYPERLOOP_EXPORT
#  define HYPERLOOP_NO_EXPORT
#else
#  ifndef HYPERLOOP_EXPORT
#    ifdef Hyperloop_EXPORTS
        /* We are building this library */
#      define HYPERLOOP_EXPORT __declspec(dllexport)
#    else
        /* We are using this library */
#      define HYPERLOOP_EXPORT __declspec(dllimport)
#    endif
#  endif

#  ifndef HYPERLOOP_NO_EXPORT
#    define HYPERLOOP_NO_EXPORT 
#  endif
#endif

#ifndef HYPERLOOP_DEPRECATED
#  define HYPERLOOP_DEPRECATED 
#endif

#ifndef HYPERLOOP_DEPRECATED_EXPORT
#  define HYPERLOOP_DEPRECATED_EXPORT HYPERLOOP_EXPORT HYPERLOOP_DEPRECATED
#endif

#ifndef HYPERLOOP_DEPRECATED_NO_EXPORT
#  define HYPERLOOP_DEPRECATED_NO_EXPORT HYPERLOOP_NO_EXPORT HYPERLOOP_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef HYPERLOOP_NO_DEPRECATED
#    define HYPERLOOP_NO_DEPRECATED
#  endif
#endif

#endif
